#!/usr/bin/env bash
# THSF Fase 8 — End-to-end cross-audit runner.
#
# Executes every gate that proves the published spec + RFCs + templates
# match the implementation. Any failure here = Fase 8 promise broken.
#
# Exit codes:
#   0 — all gates passed
#   1 — any gate failed (specific gate name printed on stderr)

set -euo pipefail

HOLON_ROOT="${HOLON_ROOT:-/home/gabrielgadea/.claude/tools/holon}"
TEMPLATES_ROOT="${TEMPLATES_ROOT:-/home/gabrielgadea/projects/templates}"
RUST_TEMPLATE="${TEMPLATES_ROOT}/holon-rust-template"
PY_TEMPLATE="${TEMPLATES_ROOT}/holon-python-template"
TS_TEMPLATE="${TEMPLATES_ROOT}/holon-ts-template"

pass=0
fail=0

gate() {
    local name="$1"; shift
    printf "%-55s " "[gate] ${name}"
    if "$@" >/tmp/thsf-audit-$$.log 2>&1; then
        printf "PASS\n"
        pass=$((pass + 1))
    else
        printf "FAIL\n"
        echo "  last 10 lines of log:" >&2
        tail -n 10 /tmp/thsf-audit-$$.log >&2
        fail=$((fail + 1))
    fi
}

cd "${HOLON_ROOT}"

# ---- RFC-001 manifest schema: 14 test cases incl. all diagnostic codes
gate "RFC-001 fixtures (14 cases)" \
    python3 -m pytest tests/test_rfc001_fixtures.py -q

# ---- RFC-003 CRDT semantics: 14 test cases incl. grow-only triggers
gate "RFC-003 CRDT semantics (14 cases)" \
    python3 -m pytest tests/test_rfc003_crdt.py -q

# ---- Original holon suite: 37 cases
gate "holon core suite (37 cases)" \
    python3 -m pytest tests/test_holon.py -q

# ---- E2E integration: 11 tests
gate "E2E cross-language integration (11 cases)" \
    python3 -m pytest tests/test_e2e_integration.py -q

# ---- Rust template: clippy -D warnings + test
gate "Rust template: clippy 0 warnings" \
    bash -c "cd '${RUST_TEMPLATE}' && cargo clippy --all-targets --quiet -- -D warnings"

gate "Rust template: cargo test (4 cases)" \
    bash -c "cd '${RUST_TEMPLATE}' && cargo test --quiet"

# ---- Python template: ruff + pytest
gate "Python template: ruff clean" \
    bash -c "cd '${PY_TEMPLATE}' && python3 -m ruff check src/ tests/"

gate "Python template: pytest (8 cases)" \
    bash -c "cd '${PY_TEMPLATE}' && PYTHONPATH=src python3 -m pytest tests/ -q"

# ---- TS template: structural JSON + manifest validation via holon.py
gate "TS template: structural integrity" \
    python3 -c "
import json, sys
for f in ('package.json', 'tsconfig.json', '.holon/schemas/echo.json'):
    json.load(open('${TS_TEMPLATE}/'+f))
sys.exit(0)
"

# ---- Cross-language transport equivalence spot check (Invariant 6)
gate "Invariant 6: Rust len == Python len" \
    bash -c "
MSG='olá THSF'
RUST=\$(echo \"{\\\"message\\\":\\\"\$MSG\\\"}\" | '${RUST_TEMPLATE}/target/release/holon-echo' echo 2>/dev/null || (cd '${RUST_TEMPLATE}' && cargo build --release --quiet && echo \"{\\\"message\\\":\\\"\$MSG\\\"}\" | ./target/release/holon-echo echo))
PY=\$(cd '${PY_TEMPLATE}' && echo \"{\\\"message\\\":\\\"\$MSG\\\"}\" | PYTHONPATH=src python3 -m holon_python_template.cli echo)
RUST_LEN=\$(echo \"\$RUST\" | python3 -c 'import json,sys;print(json.load(sys.stdin)[\"length\"])')
PY_LEN=\$(echo \"\$PY\" | python3 -c 'import json,sys;print(json.load(sys.stdin)[\"length\"])')
test \"\$RUST_LEN\" = \"\$PY_LEN\" && test \"\$RUST_LEN\" = 8
"

# ---- New suites added in Fase 8 follow-ups
gate "retention.py (7 cases)" \
    python3 -m pytest tests/test_retention.py -q

gate "mcp_server.py (12 cases)" \
    python3 -m pytest tests/test_mcp_server.py -q

gate "conformance suite (14 public gates)" \
    python3 /home/gabrielgadea/.claude/rust/docs/thsf/conformance/tests/test_conformance.py --impl=reference

gate "holon doctor on templates (0 errors)" \
    bash -c "python3 '${HOLON_ROOT}/holon.py' doctor '${TEMPLATES_ROOT}' | python3 -c 'import json,sys; d=json.load(sys.stdin); sys.exit(0 if d[\"errors\"]==0 else 1)'"

gate "holon doctor on konverter (0 errors)" \
    bash -c "python3 '${HOLON_ROOT}/holon.py' doctor /home/gabrielgadea/projects/konverter | python3 -c 'import json,sys; d=json.load(sys.stdin); sys.exit(0 if d[\"errors\"]==0 else 1)'"

gate "konverter pilot: file-info invokable" \
    bash -c "python3 '${HOLON_ROOT}/holon.py' invoke konverter file-info '{\"path\":\"README.md\"}' --root /home/gabrielgadea/projects | python3 -c 'import json,sys; d=json.load(sys.stdin); sys.exit(0 if d[\"exit_code\"]==0 else 1)'"

gate "konverter pilot: health-check invokable" \
    bash -c "python3 '${HOLON_ROOT}/holon.py' invoke konverter health-check '{}' --root /home/gabrielgadea/projects | python3 -c 'import json,sys; d=json.load(sys.stdin); sys.exit(0 if d[\"exit_code\"]==0 else 1)'"

# ---- analise pilot (Fase 8 follow-up wave C)
gate "analise pilot: health-check invokable" \
    bash -c "python3 '${HOLON_ROOT}/holon.py' invoke kazuba-geo-engine health-check '{}' --root /home/gabrielgadea/projects | python3 -c 'import json,sys; d=json.load(sys.stdin); sys.exit(0 if d[\"exit_code\"]==0 else 1)'"

gate "analise pilot: package-registry invokable" \
    bash -c "python3 '${HOLON_ROOT}/holon.py' invoke kazuba-geo-engine package-registry '{}' --root /home/gabrielgadea/projects --timeout 60 | python3 -c 'import json,sys; d=json.load(sys.stdin); out=json.loads(d.get(\"stdout\",\"{}\")); sys.exit(0 if d[\"exit_code\"]==0 and out.get(\"count\",0)>=5 else 1)'"

gate "analise pilot: workspace-stats (scoped scan)" \
    bash -c "python3 '${HOLON_ROOT}/holon.py' invoke kazuba-geo-engine workspace-stats '{\"root\":\"/home/gabrielgadea/projects/analise/packages\"}' --root /home/gabrielgadea/projects --timeout 60 | python3 -c 'import json,sys; d=json.load(sys.stdin); out=json.loads(d.get(\"stdout\",\"{}\")); sys.exit(0 if d[\"exit_code\"]==0 and out.get(\"total_files\",0)>100 else 1)'"

gate "holon doctor on analise (0 errors)" \
    bash -c "python3 '${HOLON_ROOT}/holon.py' doctor /home/gabrielgadea/projects/analise | python3 -c 'import json,sys; d=json.load(sys.stdin); sys.exit(0 if d[\"errors\"]==0 else 1)'"

# ---- analise sub-holons (Fase 8 follow-up wave D — 2026-04-24)
# Consolidated into a single pytest suite that covers all 9 capabilities
# across 5 dimensions (discovery, doctor, direct invoke, holon-invoke
# transport, edge-case exit code matrix, semantic correctness, stdlib
# guard). 112 assertions vs the 12 ad-hoc gates this replaces.

gate "analise sub-holons E2E (112 cases)" \
    python3 -m pytest tests/test_analise_subholons.py -q --tb=line

# ---- Wave T2 (2026-04-25) — mutation-test gate (advisory, skip-aware)
# Skips cleanly when cargo-mutants is absent (CI without optional deps,
# fresh dev VM, etc.) or when the touring binary is missing. Threshold
# 50% matches week 1-2 baseline per docs/mutation-testing.md ramp-up.
# The gate consults the cached report (touring mutation-test --cache-only)
# rather than re-running mutation testing — full scans live in the
# scheduled `mutation-baseline` CI job. Passes when threshold met OR no
# cache yet (initial state). Fails only when cache exists AND kill_rate
# is below threshold.
gate "mutation-test (touring-ast, advisory) [skip if absent]" \
    bash -c '
        if ! command -v cargo-mutants >/dev/null 2>&1; then
            echo "cargo-mutants not installed — skipping (advisory gate)"
            exit 0
        fi
        if ! command -v touring >/dev/null 2>&1; then
            echo "touring binary not on PATH — skipping (advisory gate)"
            exit 0
        fi
        # Cache-only read (zero cost). The scheduled CI job populates the cache.
        # check_mutation_test_gate.py applies the advisory policy:
        # cache_miss / wrapper_error → PASS; below threshold → FAIL.
        touring mutation-test --package touring-ast --threshold 50 --cache-only 2>/dev/null \
            | python3 "${HOLON_ROOT}/tests/check_mutation_test_gate.py"
    '

rm -f /tmp/thsf-audit-$$.log

echo
echo "==== Audit summary: ${pass} pass / ${fail} fail ===="
if [ "${fail}" -gt 0 ]; then
    exit 1
fi
exit 0
