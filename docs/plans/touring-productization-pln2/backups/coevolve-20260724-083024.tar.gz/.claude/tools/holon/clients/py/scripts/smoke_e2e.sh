#!/usr/bin/env bash
# smoke_e2e.sh — THSF Fase 3 D3.3 end-to-end smoke test.
#
# Spawns the release Rust daemon against a deterministic tempdir holarchy,
# then runs the generic client + both demos, collecting exit codes.
#
# Exit 0 on full success; non-zero on any failure (prints the offender).
set -euo pipefail

BASE=/home/gabrielgadea/.claude/tools/holon/clients/py
DAEMON_BIN=/home/gabrielgadea/.claude/rust/target/release/touring-capnp
SOCKET="${THSF_D33_SOCKET:-/tmp/thsf-d33-e2e.sock}"
HOLARCHY="${THSF_D33_ROOT:-/tmp/thsf-d33-holarchy}"
PY="${BASE}/.venv/bin/python"

if [[ ! -x "${DAEMON_BIN}" ]]; then
    echo "smoke_e2e: daemon missing at ${DAEMON_BIN}" >&2
    echo "  hint: cargo build -p touring-capnp-server --release" >&2
    exit 2
fi
if [[ ! -x "${PY}" ]]; then
    echo "smoke_e2e: venv python missing at ${PY}" >&2
    exit 2
fi

# Fixture holarchy — 2 holons, the second offering 'ping'
mkdir -p "${HOLARCHY}/h-primary/.holon"
mkdir -p "${HOLARCHY}/h-secondary/.holon"
cat > "${HOLARCHY}/h-primary/.holon/manifest.toml" <<'EOF'
[holon.identity]
name = "d33-primary"
version = "1.0.0"
description = "D3.3 smoke primary"
autonomy_guarantee = true
EOF
cat > "${HOLARCHY}/h-secondary/.holon/manifest.toml" <<'EOF'
[holon.identity]
name = "d33-secondary"
version = "2.1.0"
description = "D3.3 smoke secondary"
autonomy_guarantee = true

[holon.offers.ping]
adapter = "cli"
adapter_cmd = "echo pong"
version = "1.0.0"
EOF

# Clean up any stale socket.
if [[ -e "${SOCKET}" ]]; then rm "${SOCKET}"; fi

# Launch daemon.
TOURING_CAPNP_SOCKET="${SOCKET}" \
TOURING_CAPNP_ROOT="${HOLARCHY}" \
"${DAEMON_BIN}" &
DAEMON_PID=$!
cleanup() {
    kill -TERM "${DAEMON_PID}" 2>/dev/null || true
    wait "${DAEMON_PID}" 2>/dev/null || true
    if [[ -e "${SOCKET}" ]]; then rm "${SOCKET}"; fi
}
trap cleanup EXIT
sleep 1

# Readiness probe.
if ! [[ -S "${SOCKET}" ]]; then
    echo "smoke_e2e: daemon failed to bind ${SOCKET}" >&2
    exit 1
fi

# ---- Test 1: generic client spec-version ---------------------------------
echo "[smoke] T1 spec-version"
VERSION="$("${PY}" "${BASE}/holon_capnp_client.py" "${SOCKET}" spec-version)"
[[ "${VERSION}" == "1.0.0" ]] || { echo "T1 FAIL: got '${VERSION}'"; exit 1; }

# ---- Test 2: list holons has 2 entries -----------------------------------
echo "[smoke] T2 list"
COUNT="$("${PY}" "${BASE}/holon_capnp_client.py" "${SOCKET}" list |
         "${PY}" -c 'import json,sys; print(len(json.load(sys.stdin)))')"
[[ "${COUNT}" == "2" ]] || { echo "T2 FAIL: got '${COUNT}' holons"; exit 1; }

# ---- Test 3: find ping returns d33-secondary -----------------------------
echo "[smoke] T3 find ping"
MATCH="$("${PY}" "${BASE}/holon_capnp_client.py" "${SOCKET}" find ping |
         "${PY}" -c 'import json,sys; d=json.load(sys.stdin); print(d[0]["name"] if d else "")')"
[[ "${MATCH}" == "d33-secondary" ]] || { echo "T3 FAIL: got '${MATCH}'"; exit 1; }

# ---- Test 4: info pipelined retrieval ------------------------------------
echo "[smoke] T4 info pipelined"
OFFER_COUNT="$("${PY}" "${BASE}/holon_capnp_client.py" "${SOCKET}" info d33-secondary |
               "${PY}" -c 'import json,sys; print(len(json.load(sys.stdin)["offers"]))')"
[[ "${OFFER_COUNT}" == "1" ]] || { echo "T4 FAIL: got '${OFFER_COUNT}' offers"; exit 1; }

# ---- Test 5: demo_analise exits 0 ----------------------------------------
echo "[smoke] T5 demo_analise"
"${PY}" "${BASE}/examples/demo_analise.py" "${SOCKET}" > /tmp/thsf-d33-analise.out 2>&1
ANALISE_RC=$?
[[ "${ANALISE_RC}" == "0" ]] || { echo "T5 FAIL: rc=${ANALISE_RC}"; cat /tmp/thsf-d33-analise.out; exit 1; }

# ---- Test 6: demo_trading exits 0 ----------------------------------------
echo "[smoke] T6 demo_trading"
"${PY}" "${BASE}/examples/demo_trading.py" "${SOCKET}" > /tmp/thsf-d33-trading.out 2>&1
TRADING_RC=$?
[[ "${TRADING_RC}" == "0" ]] || { echo "T6 FAIL: rc=${TRADING_RC}"; cat /tmp/thsf-d33-trading.out; exit 1; }

echo "[smoke] PASS: 6/6 tests (spec/list/find/info/analise/trading)"
