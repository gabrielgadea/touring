# THSF Fase 3 D3.3 — Python Client (pycapnp)

Cliente Python asyncio para o daemon Rust `touring-capnp` (D3.2). Expõe
uma API simples (`HolonCapnpClient`) ou CLI pronta.

## Setup

```bash
# Venv isolado com pycapnp 2.x
cd /home/gabrielgadea/.claude/tools/holon/clients/py
python3 -m venv .venv
.venv/bin/pip install pycapnp
```

## Uso programático

```python
import asyncio
from holon_capnp_client import HolonCapnpClient

async def main():
    sock = "/run/user/1000/holon/registry.sock"
    async with HolonCapnpClient.connect(sock) as client:
        version = await client.spec_version()
        holons  = await client.list_holons()
        info    = await client.get_holon_info("touring-master")  # 1-RTT pipelined
        result  = await client.invoke(
            "touring-master", "symbol-index",
            {"symbol": "HookRuntime"},
            requester="my-app",
        )
        print(version, len(holons), result["exit_code"])

asyncio.run(main())
```

## CLI

```bash
./.venv/bin/python holon_capnp_client.py <socket> spec-version
./.venv/bin/python holon_capnp_client.py <socket> list
./.venv/bin/python holon_capnp_client.py <socket> find symbol-index
./.venv/bin/python holon_capnp_client.py <socket> info touring-master
./.venv/bin/python holon_capnp_client.py <socket> invoke <holon> <cap> '{}'
./.venv/bin/python holon_capnp_client.py <socket> symbiosis
```

## Examples (integrações simuladas)

- `examples/demo_analise.py` — pattern para `kazuba-geo-engine` consumir
  `symbol-index` durante EVTEA Monte Carlo.
- `examples/demo_trading.py` — pattern para `claude-trading` consumir
  `mcts-planner` / `linucb-tuner` com promise pipelining.

Ambos são **standalone** — nenhum código dos projetos alvo foi
modificado (princípio THSF: `autonomy_guarantee`). Para integrar em
produção, copie o pattern para dentro do projeto sob um módulo de
integração opcional.

## Smoke E2E

```bash
./scripts/smoke_e2e.sh     # 6/6 tests, spawns daemon + client
```

## Benchmarks (D3.4)

Harness bimodal para medir latência capnp vs fs-baseline subprocess.
O target do plano mestre (§5) é **capnp P50 < 1ms**.

```bash
# Full run (N=1000, ~15s total)
../../benchmarks/bench_d34.sh

# Smoke (N=100, ~5s total)
THSF_D34_RUNS=100 THSF_D34_INVOKE_RUNS=20 THSF_D34_WARMUP=20 \
    ../../benchmarks/bench_d34.sh
```

**Resultado validado (2026-04-23)**: Rust P50 = 9μs, Python P50 = 44μs
(ambos >20× abaixo do target). Speedup vs `holon discover`: **~1018×**
para queries leves. Relatório completo em
`~/.claude/rust/docs/2026-04-23-thsf-fase3-d34-benchmark.md`.

## Troubleshooting

| Sintoma | Causa | Fix |
|---|---|---|
| `KJ event-loop is not running` | kj_loop context não entrado | Usar `HolonCapnpClient.connect(...)` (já embrulha) |
| `got multiple values for keyword 'name'` | pycapnp positional+kwarg colisão | Usar `<method>_request()` + attribute set |
| `unix_path keyword unexpected` | `create_connection` é TCP | Usar `create_unix_connection` (já corrigido) |
| `ModuleNotFoundError: capnp` | pip install não rodou no venv correto | `.venv/bin/pip install pycapnp` |
