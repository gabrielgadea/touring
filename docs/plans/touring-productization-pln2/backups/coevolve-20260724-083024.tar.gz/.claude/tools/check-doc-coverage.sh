#!/usr/bin/env bash
# check-doc-coverage.sh — CI gate for `missing_docs` lint coverage.
#
# FASE 7 of the W13.1 → P2.7.7 doc-completeness wave.  Runs `cargo
# build` against every workspace crate, counts `missing_docs`
# warnings, and exits non-zero if any crate regresses.
#
# Usage:
#   ./check-doc-coverage.sh                  # check all crates
#   ./check-doc-coverage.sh touring-foundation  # check one crate
#   CRATE_LIST="a b c" ./check-doc-coverage.sh
#
# Exit codes:
#   0  — all crates have 0 missing_docs warnings
#   1  — one or more crates have missing_docs warnings
#   2  — invalid arguments
#   3  — tooling error (cargo not found, etc.)

set -euo pipefail

WORKSPACE="${WORKSPACE:-${HOME}/.claude/rust}"
CRATES_TO_CHECK=("$@")
if [[ ${#CRATES_TO_CHECK[@]} -eq 0 ]]; then
    # default: all crates that have a Cargo.toml
    CRATES_TO_CHECK=()
    for d in "${WORKSPACE}"/crates/*/; do
        [[ -f "$d/Cargo.toml" ]] || continue
        CRATES_TO_CHECK+=("$(basename "$d")")
    done
fi

if [[ ${#CRATES_TO_CHECK[@]} -eq 0 ]]; then
    echo "ERROR: no crates found in ${WORKSPACE}/crates/" >&2
    exit 2
fi

if ! command -v cargo >/dev/null 2>&1; then
    echo "ERROR: cargo not on PATH" >&2
    exit 3
fi

total_crates=${#CRATES_TO_CHECK[@]}
total_warnings=0
failing_crates=()

printf "Checking doc coverage for %d crates in %s\n\n" "$total_crates" "$WORKSPACE"

cd "$WORKSPACE"

for crate in "${CRATES_TO_CHECK[@]}"; do
    cargo_manifest="${WORKSPACE}/crates/${crate}/Cargo.toml"
    if [[ ! -f "$cargo_manifest" ]]; then
        printf "  [SKIP] %s — no Cargo.toml\n" "$crate"
        continue
    fi

    # Build and count missing_docs warnings.  Strip the "warning:"
    # prefix and count only the "missing documentation" entries.
    out=$(cargo build -p "$crate" 2>&1 || true)
    count=$(printf '%s\n' "$out" \
        | grep -cE '^warning: missing documentation' || true)

    if [[ "$count" -eq 0 ]]; then
        printf "  [ OK ] %-30s 0 warnings\n" "$crate"
    else
        printf "  [FAIL] %-30s %d warnings\n" "$crate" "$count"
        failing_crates+=("$crate")
        total_warnings=$((total_warnings + count))
    fi
done

echo
if [[ "$total_warnings" -eq 0 ]]; then
    echo "✓ All $total_crates crates have 0 missing_docs warnings."
    echo "  Doc coverage invariant holds."
    exit 0
else
    printf "✗ %d crates have %d total missing_docs warnings:\n" \
        "${#failing_crates[@]}" "$total_warnings"
    for c in "${failing_crates[@]}"; do
        echo "    - $c"
    done
    echo
    echo "  Run \`cargo clippy --fix\` on the failing crate or add"
    echo "  /// doc comments to the cited symbols.  See"
    echo "  ~/.claude/rust/crates/touring-foundation/ES1-DOC-COMPLETENESS.md"
    echo "  for the canonical doc style."
    exit 1
fi
