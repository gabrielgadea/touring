#!/usr/bin/env bash
# ensure_daemon.sh — SessionStart hook
#
# Verifica se o touring-daemon está ativo.
# Se não estiver, inicia-o e aguarda o warm-up.
# Retorna JSON com additionalContext para o Claude Code.
# Exit code é SEMPRE 0 (nunca bloqueia a sessão).

set -euo pipefail

DAEMON_BIN="$HOME/.claude/rust/target/release/touring-daemon"
HOOK_BIN="$HOME/.claude/rust/target/release/touring-hook"
LOG_FILE="/tmp/touring-daemon.log"
WARMUP_SECS=2
MAX_WAIT_SECS=8

# ── helpers ──────────────────────────────────────────────────────────────────

check_health() {
    "$HOOK_BIN" --daemon-health 2>/dev/null | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    print('ok' if d.get('status') == 'healthy' else 'degraded')
except Exception:
    print('down')
" 2>/dev/null || echo "down"
}

output_json() {
    local msg="$1"
    python3 -c "import json,sys; print(json.dumps({'additionalContext': sys.argv[1]}, ensure_ascii=False))" "$msg"
}

# ── main ─────────────────────────────────────────────────────────────────────

STATUS=$(check_health)

if [ "$STATUS" = "ok" ]; then
    output_json "touring-daemon: ativo e saudável"
    exit 0
fi

# Daemon não está rodando — iniciar
if [ ! -x "$DAEMON_BIN" ]; then
    output_json "touring-daemon: binário não encontrado em $DAEMON_BIN"
    exit 0
fi

nohup "$DAEMON_BIN" >> "$LOG_FILE" 2>&1 &

# Aguarda warm-up com timeout
elapsed=0
while [ "$elapsed" -lt "$MAX_WAIT_SECS" ]; do
    sleep 1
    elapsed=$((elapsed + 1))
    STATUS=$(check_health)
    if [ "$STATUS" = "ok" ]; then
        output_json "touring-daemon: iniciado (warm-up ${elapsed}s) — ativo"
        exit 0
    fi
done

# Timeout — daemon não respondeu mas pode ainda estar subindo
output_json "touring-daemon: iniciado (aguardando warm-up > ${MAX_WAIT_SECS}s)"
exit 0
