#!/usr/bin/env bash
# touring-quality-block-all.sh — Master PreToolUse hook for ALL 6 BLOCK dims (F2.1/F2.4/F2.5/F2.6/F4.3/F4.5)
#
# Scores the content that WILL be on disk after the operation (Write content / Edit applied / on-disk
# fallback) on the 6 P0 dims via `touring-quality score --format json`. If ANY P0 dim < 0.5, denies.
#
# BLOCK mechanism: print {"decision":"deny","reason":...} to stdout + exit 0 (same proven pattern as
# block_git.sh). Exit 0 with no output = allow. Fail-OPEN by design (never breaks a session) but LOUD:
# every fail-open path logs a WARN to /tmp/hook_invocations.log so a silent disable is observable.
#
# v2 (2026-06-20): covers NEW files (Write content) + Edit-applied content + expanded extensions
#                  (.tsx/.jsx/.c/.cpp/.cc/.cxx/.h/.hpp/.kt/.swift) + loud fail-open.

set -uo pipefail
export LC_ALL=C
LOG=/tmp/hook_invocations.log
log() { echo "[$(date +%H:%M:%S)] $*" >> "$LOG" 2>/dev/null; }
log "touring-quality-block-all.sh invoked PID=$$"

INPUT=$(cat)

# --- tool dependencies (LOUD fail-open) ---
TQ_BIN=$(command -v touring-quality 2>/dev/null || true)
{ [ -n "$TQ_BIN" ] && [ -x "$TQ_BIN" ]; } || TQ_BIN="$HOME/.claude/rust/crates/touring-quality/target/release/touring-quality"
[ -x "$TQ_BIN" ] || TQ_BIN="$HOME/.claude/rust/crates/touring-quality/target/debug/touring-quality"
if [ ! -x "$TQ_BIN" ]; then log "WARN fail-open: touring-quality binary not found — 50-dim BLOCK DISABLED"; exit 0; fi
if ! command -v jq >/dev/null 2>&1; then log "WARN fail-open: jq not found — BLOCK DISABLED"; exit 0; fi

FILE_PATH=$(printf '%s' "$INPUT" | jq -r '.tool_input.file_path // .tool_input.path // ""' 2>/dev/null)
[ -z "$FILE_PATH" ] && exit 0

# --- path filter: code (all guarded extensions) + manifests ---
case "$FILE_PATH" in
  *.rs|*.py|*.js|*.jsx|*.ts|*.tsx|*.go|*.java|*.kt|*.swift|*.c|*.cc|*.cpp|*.cxx|*.h|*.hpp|*.toml|*.json|*.yaml|*.yml) ;;
  *) exit 0 ;;
esac

# --- allowlist: touring-quality's own detector source legitimately contains
# provider markers (ghp_/AKIA/sk_live_/...) as DATA + secret-shaped test fixtures.
# Scoring it would always self-flag (F2.4=0.0), denying any edit to the detector
# crate. gitleaks-style path allowlist (D17 #3): trust the detector's own source.
case "$FILE_PATH" in
  */touring-quality/src/*|*/touring-quality/tests/*)
    log "ALLOWLIST skip (touring-quality detector own source): $FILE_PATH"; exit 0 ;;
esac

# --- build candidate content = post-operation disk state (truly preventive) ---
EXT=".${FILE_PATH##*.}"
TARGET="$FILE_PATH"
TMP=""
cleanup() { [ -n "${TMP:-}" ] && rm -f "$TMP" 2>/dev/null; return 0; }
trap cleanup EXIT

if command -v python3 >/dev/null 2>&1; then
  TMP=$(mktemp --suffix="$EXT" 2>/dev/null || mktemp 2>/dev/null || echo "")
  if [ -n "$TMP" ]; then
    INPUT="$INPUT" FP="$FILE_PATH" OUT="$TMP" python3 - <<'PY'
import json, os, sys
try:
    inp = json.loads(os.environ.get("INPUT", "{}"))
except Exception:
    sys.exit(2)
fp = os.environ["FP"]; out = os.environ["OUT"]
ti = inp.get("tool_input", {}) or {}
content = None
if ti.get("content") is not None:                 # Write (new or overwrite)
    content = ti["content"]
elif "new_string" in ti:                          # Edit — apply to current content
    base = ""
    if os.path.exists(fp):
        try:
            base = open(fp, encoding="utf-8", errors="replace").read()
        except Exception:
            base = ""
    old = ti.get("old_string", ""); new = ti.get("new_string", "")
    content = base.replace(old, new) if ti.get("replace_all") else base.replace(old, new, 1)
elif os.path.exists(fp):                           # fallback: on-disk content
    try:
        content = open(fp, encoding="utf-8", errors="replace").read()
    except Exception:
        content = None
if content is None:
    sys.exit(3)                                    # nothing to score (e.g. new file w/o content)
open(out, "w", encoding="utf-8").write(content)
PY
    RC=$?
    if [ "$RC" = "3" ]; then exit 0; fi
    if [ "$RC" = "0" ]; then
      TARGET="$TMP"
    elif [ -f "$FILE_PATH" ]; then
      TARGET="$FILE_PATH"; log "WARN candidate-build rc=$RC for $FILE_PATH — scoring on-disk"
    else
      log "WARN fail-open: cannot build candidate (rc=$RC) for new $FILE_PATH"; exit 0
    fi
  elif [ -f "$FILE_PATH" ]; then
    TARGET="$FILE_PATH"
  else
    exit 0
  fi
else
  # no python3: degrade to scoring on-disk existing files only (loud)
  log "WARN python3 not found — Edit/new-file scoring degraded to on-disk only"
  [ -f "$FILE_PATH" ] || exit 0
  TARGET="$FILE_PATH"
fi

# --- score candidate on the 6 BLOCK dims ---
SCORE_JSON=$($TQ_BIN score "$TARGET" --format json 2>/dev/null)
if [ -z "$SCORE_JSON" ]; then log "WARN fail-open: empty score JSON for $FILE_PATH"; exit 0; fi

BLOCKER=""
for dim in F2.1 F2.4 F2.5 F2.6 F4.3 F4.5; do
  key=${dim//./_}
  SCORE=$(printf '%s' "$SCORE_JSON" | jq -r ".dimensions.${key}.value // 1.0" 2>/dev/null)
  [ -z "$SCORE" ] && SCORE=1.0
  if awk -v s="$SCORE" 'BEGIN{exit !(s+0 < 0.5)}'; then
    EVIDENCE=$(printf '%s' "$SCORE_JSON" | jq -r ".dimensions.${key}.evidence // \"\"" 2>/dev/null)
    BLOCKER="${BLOCKER}${dim} ($(printf '%.2f' "$SCORE")): ${EVIDENCE}\n"
  fi
done

if [ -n "$BLOCKER" ]; then
  REASON="⛔ BLOCK: 50-dim P0 gate failed for $FILE_PATH — $(printf '%b' "$BLOCKER" | tr '\n' '|') Fix: touring-quality check --gate <dim> --target $FILE_PATH ; remediate via taco-forge perfect-edit"
  REASON_ESC=$(printf '%s' "$REASON" | tr '\n' ' ' | sed 's/"/'\''/g')
  printf '{"decision":"deny","reason":"%s"}\n' "$REASON_ESC"
  log "DENY $FILE_PATH"
  exit 0
fi
exit 0
