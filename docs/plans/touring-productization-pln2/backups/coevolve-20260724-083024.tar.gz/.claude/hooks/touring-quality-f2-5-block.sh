#!/usr/bin/env bash
# touring-quality-f2-5-block.sh — PreToolUse BLOCK hook for F2.5 (dependency CVEs)
#
# Status: OPTIONAL granular alternative — NOT registered in settings.json. The active
#   master hook is touring-quality-block-all.sh (covers all 6 P0 dims incl. F2.5 via the
#   real RustSec engine). Register this only for a single-dim F2.5-only gate:
#   "PreToolUse": [{ "matcher": "Edit|Write", "hooks": [{"type": "command",
#     "command": "$HOME/.claude/hooks/touring-quality-f2-5-block.sh"}] }]
#
# Behavior:
# - For Cargo.toml/package.json/pyproject.toml edits: runs F2.5 verifier
# - If score < 0.5: emit BLOCK decision with canonical fix
# - Otherwise: emit allow
#
# Exit 0 always (fail-open per CEG pattern, but emits structured block via stderr)
# Exit 2 = BLOCK (per PreToolUse semantics)
# Exit 0 = allow

set -uo pipefail
export LC_ALL=C  # pt_BR locale: printf '%.2f' must emit '.' not ',' (disk-hygiene REGRA #7)

# Read tool input from stdin (Claude Code passes hook input as JSON)
INPUT=$(cat)

# Extract file_path
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // .tool_input.path // ""' 2>/dev/null)

# Only check manifest files
case "$FILE_PATH" in
  *Cargo.toml|*package.json|*pyproject.toml|*requirements.txt) ;;
  *) exit 0 ;;  # Not a manifest → allow
esac

# Find the touring-quality binary
TQ_BIN=$(command -v touring-quality 2>/dev/null || echo "$HOME/.claude/rust/crates/touring-quality/target/release/touring-quality")
if [ ! -x "$TQ_BIN" ] && [ ! -f "$TQ_BIN" ]; then
  # Fallback: try cargo run (slow but works)
  TQ_BIN="cargo run --manifest-path $HOME/.claude/rust/crates/touring-quality/Cargo.toml --bin touring-quality --quiet --"
fi

# Run F2.5 verifier
SCORE_OUTPUT=$($TQ_BIN check --gate F2.5 --target "$FILE_PATH" --format json 2>/dev/null)
if [ -z "$SCORE_OUTPUT" ]; then
  # Verifier not available — fail-open
  exit 0
fi

# Parse score
SCORE=$(echo "$SCORE_OUTPUT" | jq -r '.dimensions.F2_5.value // 1.0' 2>/dev/null)
EVIDENCE=$(echo "$SCORE_OUTPUT" | jq -r '.dimensions.F2_5.evidence // "no evidence"' 2>/dev/null)

# Threshold
if awk -v s="$SCORE" 'BEGIN{exit !(s+0 < 0.5)}'; then
  # BLOCK
  cat <<EOF >&2
{
  "decision": "block",
  "reason": "⛔ BLOCK F2.5 (dep CVEs): score $(printf '%.2f' $SCORE)\n\nEvidence: $EVIDENCE\n\nCanonical fix: \`cargo update -p <crate>\` for patchable advisories; for unmaintained/unfixable, add a justified [advisories.ignore] entry to deny.toml; bump pinned versions via \`taco-forge perfect-edit --path $FILE_PATH\`.\n\nRule: ~/.claude/rules/quality/D14_dep_cves.md"
}
EOF
  exit 2  # PreToolUse BLOCK exit code
else
  # Allow
  exit 0
fi
