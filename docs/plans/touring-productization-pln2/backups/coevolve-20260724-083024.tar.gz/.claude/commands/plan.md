---
name: plan
description: Generate deterministic agentic plan via /plan ou skill taco-planning --quality high --auto-populate 
handoff:
  agent: engineer
  phase: 5
  task: D44-speckit-commands
---
# /plan — Generate Plan via Touring-native tooling 

Generate a deterministic, agentic plan via `/plan ou skill taco-planning --quality high --auto-populate`. **Never via Write tool** — edição-com-gate (AGENTIC PARADIGM).

## Usage

```
/plan <intent description>
```

Example:

```
/plan implement RBAC system with role hierarchy and permission inheritance
```

## What This Command Does

Invokes the canonical agentic plan pipeline that produces:

- `~/.claude/rust/docs/plans/<YYYY-MM-DD>-<slug>.md` — chunked markdown plan (8 KiB threshold)
- `checkpoints/discover.toon` — DISCOVER 11-signal serialized
- `checkpoints/vgp.toon` — VGP V1+V2+V3+V4 batch verification
- `checkpoints/plan_spec.toon` — PlanSpec dataclass
- `validators/validate-phase-<id>.sh` — deep validators per phase
- `audit-plan-completion.sh` — cross-audit script (9 gates)
- DAG nativo Touring auto-populado via `touring decompose`

## Execution

When invoked with `/plan <intent>`, run this exact bash:

```bash
SLUG=$(echo "$ARGUMENTS" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]\+/-/g' | sed 's/^-//;s/-$//' | cut -c1-50)
DATE=$(date +%Y-%m-%d)
OUT=~/.claude/rust/docs/plans/${DATE}-${SLUG}.md

TF_WORKSPACE=~/.claude/rust /plan ou skill taco-planning \
  --intent "$ARGUMENTS" \
  --quality high \
  --cila-level 3 \
  --out "$OUT" \
  --auto-populate
```

Then report to user:

1. **Path** of generated plan: `$OUT`
2. **DAG task_id** from `touring decompose status -j` (latest entry)
3. **Validators created** (`ls plans/validators/*.sh | wc -l`)
4. **Cross-audit script** path
5. **VGP report**: X/Y symbols verified

## Why /plan Exists

The TACO ecosystem enforces edição-com-gate (AGENTIC PARADIGM) at two layers:

| Layer | Enforcement |
|---|---|
| **E1 (gate)** | `~/.claude/hooks/plan-detector.sh` — blocks Write tool when content matches plan patterns (`## Wave`, `## Phase`, numbered deliverables, etc.) with exit 2 |
| **E3 (ergonomic)** | `/plan <intent>` — same effort as Write, but routed through the canonical agentic pipeline |

Together they close the loop: gate prevents wrong path, slash command makes the right path frictionless.

## What `/plan ou skill taco-planning --quality high` Provides

The Code-First Python pipeline (`~/.claude/tools/Touring-native tooling/lib/plan_quality/cli.py`, ~1.500 LOC stdlib-only) runs:

1. **Stage 1/6** — DISCOVER 11-signal pipeline (parallel via threading)
2. **Stage 2/6** — VGP batch (V1 extract + V2 verify + V3 blast_radius + V4 cache)
3. **Stage 3/6** — PlanSpec serialization (TOON v1.0)
4. **Stage 4/6** — Markdown rendering (chunked at 8 KiB threshold)
5. **Stage 5/6** — Validators + TDD skeletons per phase
6. **Stage 6/6** — Cross-audit script (9 gates: precisão, escalabilidade, performance, aplicabilidade, code quality, detalhe, integração sistêmica, dependencies, potencialização)

ADR: `~/.claude/tools/Touring-native tooling/docs/2026-05-01-ADR-plan-quality-pipeline.md`.

## Edge Cases

- **No arguments**: respond "Usage: /plan <intent description>"
- **Daemon down**: output of `/plan ou skill taco-planning` will warn; pipeline continues with degraded mode (memory_hits=0, tantivy_hits=0)
- **Existing plan at output path**: Touring-native tooling appends timestamp suffix automatically
- **Intent > 8 KiB output**: automatic chunking into `plan.part-NN.md` parts

## See Also

- `~/.claude/CLAUDE.md` — edição-com-gate (AGENTIC PARADIGM) + REGRA #16 (CLAUDE.MD HYGIENE)
- `~/.claude/rules/touring-decision-matrix.md` — REGRAS #1–#8
- `~/.claude/hooks/plan-detector.sh` — E1 enforcement script
- `~/.claude/skills/Touring-native tooling/SKILL.md` — full Touring-native tooling reference
- `touring memory recall plan-then-populate` — embedded recipe
