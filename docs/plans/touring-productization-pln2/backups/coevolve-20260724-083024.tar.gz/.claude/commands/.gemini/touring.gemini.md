---
agent: gemini
version: "1.0"
created: 2026-05-03
handoff_from: touring-engineer
handoff_to: gemini-agent
---

# Gemini CLI Agent Configuration for Touring Integration

## Overview

This file provides Gemini CLI agents with the necessary context and commands to interact with the Touring CLI system. Gemini agents can use Touring for project analysis, agent orchestration, and code intelligence.

## Touring CLI Invocation Patterns

### System Health

```bash
# Full health check
touring doctor -j

# Status dashboard
touring status -j

# E2E validation
touring e2e -j
```

### Code Analysis

```bash
# File metadata
touring ast meta <file> --depth summary -j

# Blast radius
touring ast blast <file>

# Rust semantic analysis
touring ast rust-semantic <file.rs>

# Format Rust
touring ast format-rust <file.rs>
```

### Symbol Discovery

```bash
# Find symbol
touring index find <symbol>

# Search
touring tantivy search "<query>"

# Fuzzy search
touring tantivy fuzzy "<query>" 2
```

### Wiring Intelligence

```bash
# Orphans
touring wiring orphans -j

# Audit
touring wiring audit -j

# Impact
touring wiring impact <symbol> --depth N
```

### Agent Workflows

```bash
# Session management
touring session start <id> type "<objective>"

# Memory
touring memory store "<key>" "<value>" --tier semantic
touring memory recall "<query>"

# Learning rewards
touring learning reward <tool> <value> [context]
```

## Handoff Protocol

When handing off to a Gemini agent:

1. Provide `touring status -j` output
2. Include relevant symbol findings
3. Specify analysis or implementation goals
4. Share session/memory context if applicable

## Agent-Specific Metadata

| Field | Value |
|-------|-------|
| Agent Type | Gemini CLI |
| Touring CLI Path | `~/.local/bin/touring` |
| Daemon Socket | `/tmp/touring-daemon-1000.sock` |
| Protocol | JSON (via `-j` flag) |
| Workspace | `~/.claude/rust/` |
