---
agent: serena
version: "1.0"
created: 2026-05-03
handoff_from: touring-engineer
handoff_to: serena-agent
---

# Serena AI Agent Configuration for Touring Integration

## Overview

This file provides Serena AI agents with the necessary context and commands to interact with the Touring CLI system. Serena agents can invoke Touring CLI commands for orchestrating multi-agent workflows, session management, and code analysis.

## Touring CLI Invocation Patterns

### Pre-Flight Health Checks

```bash
# Comprehensive health check (always run first)
touring doctor -j

# System dashboard
touring status -j

# Gate metrics for agent performance
touring gate-metrics -j
```

### Session Orchestration

```bash
# Initialize a new session
touring session start <session_id> type "<objective>"

# End session with quality assessment
touring session assess <session_id>
```

### Task Decomposition

```bash
# Create a new task DAG
touring decompose create <type> "<description>"

# Add subtasks with dependencies
touring decompose add <task_id> <subtask_id> --depends-on=<dep1>,<dep2>

# Track decomposition status
touring decompose status -j
```

### Agent Communication

```bash
# Store memory for cross-agent context
touring memory store "<key>" "<value>" --tier semantic

# Recall relevant context
touring memory recall "<query>"

# Record lesson learned
touring memory store "lesson:<domain>:<topic>" "<content>" --tier semantic
```

### Reinforcement Learning Signals

```bash
# Reward successful orchestration
touring learning reward orchestrate 1.0 "<context>"

# Reward speculative validation
touring learning reward speculate 1.0 "<context>"

# Reward edit quality
touring learning reward edit 1.0 "<context>"
```

### Cross-Subsystem Analysis

```bash
# Synergy report
touring synergy -j

# Synergy with metrics
touring synergy --with-metrics -j

# Evolution insights
touring evolution insights -j

# Drift detection
touring evolution drift -j
```

## Handoff Protocol

When receiving handoff from another agent or handing off to Serena:

1. Include `touring status -j` output
2. Provide relevant session ID if active
3. Share decomposition DAG status
4. Include any stored memories relevant to the task

## Agent-Specific Metadata

| Field | Value |
|-------|-------|
| Agent Type | Serena AI |
| Touring CLI Path | `~/.local/bin/touring` |
| Daemon Socket | `/tmp/touring-daemon-1000.sock` |
| Protocol | JSON (via `-j` flag) |
| Workspace | `~/.claude/rust/` |
