---
agent: specify
version: "1.0"
created: 2026-05-03
handoff_from: touring-engineer
handoff_to: specify-agent
---

# Specify AI Agent Configuration for Touring Integration

## Overview

This file provides Specify AI agents with the necessary context and commands to interact with the Touring CLI system. Specify agents can invoke Touring CLI commands for code analysis, agent orchestration, and project health monitoring.

## Touring CLI Invocation Patterns

### Health and Status Checks

```bash
# Full system health check
touring doctor -j

# Project dashboard (index, orphans, RL metrics)
touring status -j

# End-to-end system validation
touring e2e -j
```

### Code Analysis

```bash
# File metadata (blast radius, quality, cognitive score)
touring ast meta <file> --depth summary -j

# Blast radius analysis
touring ast blast <file>

# Rust semantic analysis
touring ast rust-semantic <file.rs>

# Format Rust code
touring ast format-rust <file.rs>
```

### Symbol Discovery

```bash
# Find symbol definition
touring index find <symbol>

# Search symbols with BM25
touring tantivy search "<query>"

# Fuzzy search
touring tantivy fuzzy "<query>" 2
```

### Wiring Intelligence

```bash
# Detect orphan symbols
touring wiring orphans -j

# Full wiring audit
touring wiring audit -j

# Wiring impact analysis
touring wiring impact <symbol> --depth N
```

### Session Management

```bash
# Start a session
touring session start <id> type "<objective>"

# Assess session quality
touring session assess <id>
```

### Memory and Learning

```bash
# Store semantic memory
touring memory store <key> <value> --tier semantic

# Recall memory
touring memory recall "<query>"

# Inject RL reward
touring learning reward <tool> <value> [context]
```

### Code Generation

```bash
# List available generator kinds
touring generate list-kinds -j

# Verify symbol before generation
touring generate verify --symbol <name>

# Render from template
touring generate render <kind> --vars '{}'
```

## Handoff Protocol

When handing off to a Specify agent:

1. Provide the `touring status -j` output for current project state
2. Include any relevant `touring memory recall` results for context
3. Specify the target file/module for analysis
4. Indicate the desired outcome (analysis, code generation, refactor)

## Agent-Specific Metadata

| Field | Value |
|-------|-------|
| Agent Type | Specify AI |
| Touring CLI Path | `~/.local/bin/touring` |
| Daemon Socket | `/tmp/touring-daemon-1000.sock` |
| Protocol | JSON (via `-j` flag) |
| Workspace | `~/.claude/rust/` |
