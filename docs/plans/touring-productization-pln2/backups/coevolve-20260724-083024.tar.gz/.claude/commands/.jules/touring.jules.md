---
agent: jules
version: "1.0"
created: 2026-05-03
handoff_from: touring-engineer
handoff_to: jules-agent
---

# Jules AI Agent Configuration for Touring Integration

## Overview

This file provides Jules AI agents with the necessary context and commands to interact with the Touring CLI system. Jules agents can leverage Touring for code analysis, agent coordination, and project intelligence.

## Touring CLI Invocation Patterns

### Project Intelligence

```bash
# File metadata and quality metrics
touring ast meta <file> --depth summary -j

# Blast radius analysis (dependencies)
touring ast blast <file>

# Extended file knowledge
touring file-knowledge extended <file>
```

### Cognitive Analysis

```bash
# Cognitive metrics
touring cognitive metrics -j

# Cognitive engine health
touring cognitive engines -j
```

### Symbol Index

```bash
# Find symbol definition
touring index find <symbol>

# Index status
touring index status

# Prefix search
touring index search <prefix>
```

### Wiring and Integration

```bash
# Detect orphan symbols
touring wiring orphans -j

# Wiring chains
touring wiring chains -j

# Module wiring score
touring wiring score <file> -j
```

### Search

```bash
# BM25 search
touring tantivy search "<query>"

# Suggest/autocomplete
touring tantivy suggest "<prefix>"

# Fuzzy search
touring tantivy fuzzy "<query>" 2
```

## Handoff Protocol

When handing off to a Jules agent:

1. Provide target file paths for analysis
2. Include `touring ast meta` output for key files
3. Share any relevant wiring/orphan information
4. Specify analysis goals

## Agent-Specific Metadata

| Field | Value |
|-------|-------|
| Agent Type | Jules AI |
| Touring CLI Path | `~/.local/bin/touring` |
| Daemon Socket | `/tmp/touring-daemon-1000.sock` |
| Protocol | JSON (via `-j` flag) |
| Workspace | `~/.claude/rust/` |
