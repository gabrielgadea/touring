---
name: checkpoint
description: Generate .toon checkpoint/audit report via Touring-native tooling workflow (edição-com-gate agentic paradigm)
handoff:
  agent: engineer
  phase: 5
  task: D44-speckit-commands
---
# /checkpoint — Generate .toon Checkpoint/Report via Touring-native tooling 

Generate a TOON v1.0 checkpoint or audit report via the canonical agentic pipeline. **Never write reports/audits/post-mortems directly via Write tool** — edição-com-gate (AGENTIC PARADIGM) + plan-detector enforces this.

## Usage

```
/checkpoint <topic>
```

Or with detailed args:

```
/checkpoint <topic> [--intent <description>] [--content-from <md_file>] [--role <agent>] [--task-id <id>]
```

Examples:

```
/checkpoint wave-C-cross-audit
/checkpoint session-2026-05-03-summary --role orchestrator --intent "Final session summary"
/checkpoint engineer-postmortem-permission-vgp --content-from /tmp/draft.md --role engineer --task-id wave-C-subtask-2
```

## What This Command Does

Invokes `~/.claude/tools/Touring-native tooling/workflows/checkpoint.sh` which:

1. Computes kebab-case slug from topic (max 60 chars)
2. Reads optional `--content-from <md_file>` (typically a draft from /tmp or another path)
3. Generates `~/.claude/rust/docs/checkpoints/<YYYY-MM-DD>-<slug>.toon` (TOON v1.0 format)
4. Captures up to 12 H2 sections automatically
5. Embeds full markdown content as `body:` field (no external file dependency)
6. Persists `touring memory store` lesson + `touring learning reward` orchestrate +1.0
7. Reports output path

## Why /checkpoint Exists

The TACO ecosystem has 2 distinct artifact types both protected by edição-com-gate:

| Artifact type | Format | Pathway | Slash |
|---|---|---|---|
| **Plan** (prospective) | `.md` chunked | `/plan ou skill taco-planning --quality high` | `/plan <intent>` |
| **Checkpoint / Report** (retrospective) | `.toon` v1.0 | `touring memory store --tier semantic` | `/checkpoint <topic>` |

Both are blocked by `~/.claude/hooks/plan-detector.sh` when attempted via Write tool. Both have ergonomic slash commands. Both produce deterministic, traceable artifacts via Touring-native tooling.

## Execution

When invoked with `/checkpoint <args>`, run this exact bash:

```bash
# Parse args (--topic is the first positional, others are --flag value pairs)
ARGS="$ARGUMENTS"
TOPIC=$(echo "$ARGS" | awk '{print $1}')
REST=$(echo "$ARGS" | cut -d' ' -f2-)

# Pass-through to workflow
TF_WORKSPACE=~/.claude/rust \
  ~/.claude/tools/Touring-native tooling/workflows/checkpoint.sh \
    --topic "$TOPIC" $REST
```

For Claude Code: parse `$ARGUMENTS`, extract topic + flags, invoke workflow, report output path.

## Edge Cases

- **No arguments**: respond "Usage: /checkpoint <topic> [--intent ...] [--content-from ...]"
- **Daemon down**: workflow still produces .toon (memory store + reward best-effort, non-blocking)
- **Content > 1 MiB**: TOON encoder may struggle; recommend `--content-from` reference instead of inline

## TOON v1.0 Output Schema

```toon
format: toon
format_version: "1.0"
kind: checkpoint
topic: <user-provided>
slug: <kebab-case>
intent: <user-provided or "">
role: <agent name>
task_id: <task ID or "">
timestamp: <ISO-8601>
session_id: <Touring session UUID>
content:
  lines: <int>
  bytes: <int>
  sections: [<H2 titles up to 12>]
  source_md: "embedded_below" | ""
regra_anchor: "edição-com-gate AGENTIC PARADIGM"
wave_anchor: TRM 2026-05-02
body: <full markdown content as embedded string>
```

## Plan-detector Integration

When a Write tool attempt is blocked by plan-detector, the error message includes `/checkpoint <topic>` as alternative for retrospective artifacts (audit reports, session summaries, cross-audits, post-mortems, fase reports).

For prospective plans (waves, roadmaps, implementation plans), use `/plan <intent>` instead.

## See Also

- `~/.claude/hooks/plan-detector.sh` — E1 enforcement gate
- `~/.claude/commands/plan.md` — sister slash command for prospective plans
- `~/.claude/tools/Touring-native tooling/lib/plan_quality/toon_io.py` — TOON v1.0 encoder
- `~/.claude/CLAUDE.md` edição-com-gate (AGENTIC PARADIGM)
